/* Used to insert values inside the database when the program runs*/
INSERT INTO inventory
	(name, price, location)
VALUES
	('Toaster', 14.99, 'Oakville'), ('Rice Cooker', 29.99, 'Mississauga');
	
INSERT INTO locations
	(name)
VALUES
	('Oakville'), ('Burlington'), ('Mississauga'), ('Toronto');
	
	