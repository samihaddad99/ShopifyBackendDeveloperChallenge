package ca.sheridancollege;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2JdbcExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
